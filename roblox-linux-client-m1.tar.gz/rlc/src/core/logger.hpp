#pragma once
#include <filesystem>
#include <format>
#include <fstream>
#include <mutex>
#include <string>
#include <string_view>

namespace rlc {

enum class LogLevel { Debug = 0, Info, Warn, Error };

class Logger {
public:
    static Logger& instance();

    bool open(const std::filesystem::path& file);
    void close();
    void setLevel(LogLevel level);
    void setConsole(bool enabled);
    void log(LogLevel level, std::string_view component, std::string_view message);

private:
    Logger() = default;
    std::mutex mutex_;
    std::ofstream file_;
    LogLevel min_ = LogLevel::Info;
    bool console_ = true;
};

template <class... Args>
void logDebug(std::string_view c, std::format_string<Args...> f, Args&&... a) {
    Logger::instance().log(LogLevel::Debug, c, std::format(f, std::forward<Args>(a)...));
}
template <class... Args>
void logInfo(std::string_view c, std::format_string<Args...> f, Args&&... a) {
    Logger::instance().log(LogLevel::Info, c, std::format(f, std::forward<Args>(a)...));
}
template <class... Args>
void logWarn(std::string_view c, std::format_string<Args...> f, Args&&... a) {
    Logger::instance().log(LogLevel::Warn, c, std::format(f, std::forward<Args>(a)...));
}
template <class... Args>
void logError(std::string_view c, std::format_string<Args...> f, Args&&... a) {
    Logger::instance().log(LogLevel::Error, c, std::format(f, std::forward<Args>(a)...));
}

} // namespace rlc
