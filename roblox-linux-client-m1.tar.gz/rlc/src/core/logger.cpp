#include "core/logger.hpp"

#include <chrono>
#include <cstdio>
#include <ctime>

namespace rlc {
namespace {
const char* levelName(LogLevel l) {
    switch (l) {
    case LogLevel::Debug: return "DEBUG";
    case LogLevel::Info:  return "INFO";
    case LogLevel::Warn:  return "WARN";
    case LogLevel::Error: return "ERROR";
    }
    return "?";
}
} // namespace

Logger& Logger::instance() {
    static Logger logger;
    return logger;
}

bool Logger::open(const std::filesystem::path& file) {
    std::lock_guard lock(mutex_);
    std::error_code ec;
    if (file.has_parent_path()) {
        std::filesystem::create_directories(file.parent_path(), ec);
        if (ec) return false;
    }
    if (file_.is_open()) file_.close();
    file_.open(file, std::ios::app);
    return file_.is_open();
}

void Logger::close() {
    std::lock_guard lock(mutex_);
    if (file_.is_open()) file_.close();
}

void Logger::setLevel(LogLevel level) {
    std::lock_guard lock(mutex_);
    min_ = level;
}

void Logger::setConsole(bool enabled) {
    std::lock_guard lock(mutex_);
    console_ = enabled;
}

void Logger::log(LogLevel level, std::string_view component, std::string_view message) {
    std::lock_guard lock(mutex_);
    if (level < min_) return;

    const auto t = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    std::tm tm{};
    localtime_r(&t, &tm);
    char ts[32];
    std::strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", &tm);

    const std::string line =
        std::format("{} [{}] [{}] {}\n", ts, levelName(level), component, message);

    if (console_) std::fputs(line.c_str(), level >= LogLevel::Warn ? stderr : stdout);
    if (file_.is_open()) {
        file_ << line;
        file_.flush();
    }
}

} // namespace rlc
