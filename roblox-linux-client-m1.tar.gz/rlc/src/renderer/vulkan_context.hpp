#pragma once
#include <vulkan/vulkan.h>

#include <cstdint>
#include <string>
#include <vector>

struct SDL_Window;

namespace rlc {

struct GpuInfo {
    std::string name;
    std::string vendor;
    std::string type;
    std::string apiVersion;
    std::string driverVersion;
    uint32_t vendorId = 0;
    uint32_t graphicsQueueFamily = 0;
};

// RAII: cria instância + surface e escolhe a GPU. Lança std::runtime_error em falha.
class VulkanContext {
public:
    explicit VulkanContext(SDL_Window* window);
    ~VulkanContext();
    VulkanContext(const VulkanContext&) = delete;
    VulkanContext& operator=(const VulkanContext&) = delete;

    const GpuInfo& gpu() const { return gpu_; }
    const std::vector<GpuInfo>& allGpus() const { return allGpus_; }

private:
    VkInstance instance_ = VK_NULL_HANDLE;
    VkSurfaceKHR surface_ = VK_NULL_HANDLE;
    GpuInfo gpu_;
    std::vector<GpuInfo> allGpus_;
};

} // namespace rlc
