#include "renderer/vulkan_context.hpp"

#include <SDL3/SDL_vulkan.h>

#include <cstring>
#include <format>
#include <stdexcept>

#include "core/logger.hpp"

namespace rlc {
namespace {

[[noreturn]] void fail(std::string what) {
    logError("vulkan", "{}", what);
    throw std::runtime_error(std::move(what));
}

void check(VkResult r, const char* call) {
    if (r != VK_SUCCESS) fail(std::format("{} falhou (VkResult {})", call, static_cast<int>(r)));
}

const char* typeName(VkPhysicalDeviceType t) {
    switch (t) {
    case VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU:   return "discreta";
    case VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU: return "integrada";
    case VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU:    return "virtual";
    case VK_PHYSICAL_DEVICE_TYPE_CPU:            return "CPU (software)";
    default:                                     return "outra";
    }
}

const char* vendorName(uint32_t id) {
    switch (id) {
    case 0x10DE: return "NVIDIA";
    case 0x1002: return "AMD";
    case 0x8086: return "Intel";
    default:     return "desconhecido";
    }
}

std::string driverVersion(uint32_t vendor, uint32_t v) {
    if (vendor == 0x10DE) // NVIDIA usa codificação própria
        return std::format("{}.{}.{}.{}", v >> 22, (v >> 14) & 0xFF, (v >> 6) & 0xFF, v & 0x3F);
    return std::format("{}.{}.{}", VK_API_VERSION_MAJOR(v), VK_API_VERSION_MINOR(v),
                       VK_API_VERSION_PATCH(v));
}

// Retorna índice da fila com suporte a gráficos + apresentação, ou -1.
int findQueueFamily(VkPhysicalDevice dev, VkSurfaceKHR surface) {
    uint32_t n = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(dev, &n, nullptr);
    std::vector<VkQueueFamilyProperties> fams(n);
    vkGetPhysicalDeviceQueueFamilyProperties(dev, &n, fams.data());
    for (uint32_t i = 0; i < n; ++i) {
        if (!(fams[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)) continue;
        VkBool32 present = VK_FALSE;
        if (vkGetPhysicalDeviceSurfaceSupportKHR(dev, i, surface, &present) == VK_SUCCESS &&
            present)
            return static_cast<int>(i);
    }
    return -1;
}

} // namespace

VulkanContext::VulkanContext(SDL_Window* window) {
    Uint32 extCount = 0;
    const char* const* exts = SDL_Vulkan_GetInstanceExtensions(&extCount);
    if (!exts) fail(std::format("SDL_Vulkan_GetInstanceExtensions: {}", SDL_GetError()));
    std::vector<const char*> extensions(exts, exts + extCount);

    std::vector<const char*> layers;
#ifndef NDEBUG
    uint32_t lc = 0;
    vkEnumerateInstanceLayerProperties(&lc, nullptr);
    std::vector<VkLayerProperties> avail(lc);
    vkEnumerateInstanceLayerProperties(&lc, avail.data());
    for (const auto& l : avail) {
        if (std::strcmp(l.layerName, "VK_LAYER_KHRONOS_validation") == 0) {
            layers.push_back("VK_LAYER_KHRONOS_validation");
            logInfo("vulkan", "Camada de validação ativada");
        }
    }
    if (layers.empty()) logWarn("vulkan", "Validação indisponível (instale vulkan-validationlayers)");
#endif

    VkApplicationInfo app{};
    app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    app.pApplicationName = "roblox-linux-client";
    app.applicationVersion = VK_MAKE_VERSION(0, 1, 0);
    app.apiVersion = VK_API_VERSION_1_1;

    VkInstanceCreateInfo ci{};
    ci.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    ci.pApplicationInfo = &app;
    ci.enabledExtensionCount = static_cast<uint32_t>(extensions.size());
    ci.ppEnabledExtensionNames = extensions.data();
    ci.enabledLayerCount = static_cast<uint32_t>(layers.size());
    ci.ppEnabledLayerNames = layers.data();
    check(vkCreateInstance(&ci, nullptr, &instance_), "vkCreateInstance");

    if (!SDL_Vulkan_CreateSurface(window, instance_, nullptr, &surface_)) {
        const std::string err = SDL_GetError();
        vkDestroyInstance(instance_, nullptr);
        instance_ = VK_NULL_HANDLE;
        fail(std::format("SDL_Vulkan_CreateSurface: {}", err));
    }

    try {
        uint32_t n = 0;
        check(vkEnumeratePhysicalDevices(instance_, &n, nullptr), "vkEnumeratePhysicalDevices");
        if (n == 0) fail("Nenhuma GPU com suporte a Vulkan encontrada");
        std::vector<VkPhysicalDevice> devs(n);
        check(vkEnumeratePhysicalDevices(instance_, &n, devs.data()), "vkEnumeratePhysicalDevices");

        int bestScore = -1;
        for (auto d : devs) {
            VkPhysicalDeviceProperties p{};
            vkGetPhysicalDeviceProperties(d, &p);
            GpuInfo g;
            g.name = p.deviceName;
            g.vendorId = p.vendorID;
            g.vendor = vendorName(p.vendorID);
            g.type = typeName(p.deviceType);
            g.apiVersion = std::format("{}.{}.{}", VK_API_VERSION_MAJOR(p.apiVersion),
                                       VK_API_VERSION_MINOR(p.apiVersion),
                                       VK_API_VERSION_PATCH(p.apiVersion));
            g.driverVersion = driverVersion(p.vendorID, p.driverVersion);
            const int q = findQueueFamily(d, surface_);
            logInfo("vulkan", "GPU: {} | {} | {} | Vulkan {} | driver {} | fila gráfica: {}",
                    g.name, g.vendor, g.type, g.apiVersion, g.driverVersion,
                    q >= 0 ? std::to_string(q) : "nenhuma utilizável");
            if (q < 0) continue;
            g.graphicsQueueFamily = static_cast<uint32_t>(q);
            allGpus_.push_back(g);

            int score = 1;
            if (p.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) score = 1000;
            else if (p.deviceType == VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU) score = 100;
            if (score > bestScore) {
                bestScore = score;
                gpu_ = g;
            }
        }
        if (bestScore < 0) fail("Nenhuma GPU com fila de gráficos + apresentação");
        logInfo("vulkan", "GPU selecionada: {}", gpu_.name);
    } catch (...) {
        SDL_Vulkan_DestroySurface(instance_, surface_, nullptr);
        vkDestroyInstance(instance_, nullptr);
        instance_ = VK_NULL_HANDLE;
        surface_ = VK_NULL_HANDLE;
        throw;
    }
}

VulkanContext::~VulkanContext() {
    if (surface_ != VK_NULL_HANDLE) SDL_Vulkan_DestroySurface(instance_, surface_, nullptr);
    if (instance_ != VK_NULL_HANDLE) vkDestroyInstance(instance_, nullptr);
}

} // namespace rlc
