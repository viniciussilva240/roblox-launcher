#include <SDL3/SDL.h>
#include <SDL3/SDL_vulkan.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <memory>

#include "core/logger.hpp"
#include "platform/linux/system_info.hpp"
#include "renderer/vulkan_context.hpp"

namespace {

constexpr const char* kVersion = "0.1.0";

std::filesystem::path logDir() {
    if (const char* s = std::getenv("XDG_STATE_HOME"); s && *s)
        return std::filesystem::path(s) / "roblox-linux-client" / "logs";
    if (const char* h = std::getenv("HOME"); h && *h)
        return std::filesystem::path(h) / ".local/state/roblox-linux-client/logs";
    return "logs";
}

struct SdlGuard {
    bool ok;
    SdlGuard() : ok(SDL_Init(SDL_INIT_VIDEO)) {}
    ~SdlGuard() { if (ok) SDL_Quit(); }
};

struct WindowDeleter {
    void operator()(SDL_Window* w) const { SDL_DestroyWindow(w); }
};

} // namespace

int main(int argc, char** argv) {
    using namespace rlc;

    bool keepOpen = false;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--keep-open")) keepOpen = true;
        else if (!std::strcmp(argv[i], "--debug")) Logger::instance().setLevel(LogLevel::Debug);
        else if (!std::strcmp(argv[i], "--help")) {
            std::puts("Uso: rlc-client [--keep-open] [--debug]");
            return 0;
        }
    }

    const auto dir = logDir();
    if (!Logger::instance().open(dir / "client.log"))
        std::fprintf(stderr, "Aviso: não foi possível abrir o log em %s\n", dir.c_str());

    const auto sys = collectSystemInfo();
    const int sdlVer = SDL_GetVersion();
    logInfo("client", "roblox-linux-client {} (Milestone 1)", kVersion);
    logInfo("client", "SO: {} | kernel {} | {}", sys.osName, sys.kernel, sys.arch);
    logInfo("client", "Sessão: {} | Desktop: {}", sys.sessionType, sys.desktop);
    logInfo("client", "SDL: {}.{}.{}", SDL_VERSIONNUM_MAJOR(sdlVer), SDL_VERSIONNUM_MINOR(sdlVer),
            SDL_VERSIONNUM_MICRO(sdlVer));

    SdlGuard sdl;
    if (!sdl.ok) {
        logError("client", "SDL_Init falhou: {}", SDL_GetError());
        return 1;
    }
    logInfo("client", "Driver de vídeo SDL: {}", SDL_GetCurrentVideoDriver());

    std::unique_ptr<SDL_Window, WindowDeleter> window(
        SDL_CreateWindow("Roblox Linux Client - Milestone 1", 1280, 720,
                         SDL_WINDOW_VULKAN | SDL_WINDOW_RESIZABLE));
    if (!window) {
        logError("client", "SDL_CreateWindow falhou: {}", SDL_GetError());
        return 1;
    }

    try {
        VulkanContext vk(window.get()); // destruído antes da janela
        logInfo("client", "Inicialização concluída. GPU: {} ({}), driver {}", vk.gpu().name,
                vk.gpu().vendor, vk.gpu().driverVersion);

        int frames = 0;
        bool running = true;
        while (running && (keepOpen || frames < 120)) {
            SDL_Event e;
            while (SDL_PollEvent(&e)) {
                if (e.type == SDL_EVENT_QUIT) running = false;
                if (e.type == SDL_EVENT_KEY_DOWN && e.key.key == SDLK_ESCAPE) running = false;
            }
            SDL_Delay(16);
            ++frames;
        }
    } catch (const std::exception& ex) {
        logError("client", "Falha fatal: {}", ex.what());
        return 2;
    }

    logInfo("client", "Encerrando normalmente");
    return 0;
}
