#pragma once
#include <istream>
#include <map>
#include <string>

namespace rlc {

struct SystemInfo {
    std::string osName;
    std::string kernel;
    std::string arch;
    std::string sessionType;
    std::string desktop;
};

// Lê pares CHAVE=VALOR no formato de /etc/os-release (ignora comentários e aspas).
std::map<std::string, std::string> parseOsRelease(std::istream& in);

SystemInfo collectSystemInfo();

} // namespace rlc
