#include "platform/linux/system_info.hpp"

#include <sys/utsname.h>

#include <cstdlib>
#include <fstream>

namespace rlc {

std::map<std::string, std::string> parseOsRelease(std::istream& in) {
    std::map<std::string, std::string> out;
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#') continue;
        const auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string key = line.substr(0, eq);
        std::string val = line.substr(eq + 1);
        if (val.size() >= 2 && (val.front() == '"' || val.front() == '\'') &&
            val.back() == val.front()) {
            val = val.substr(1, val.size() - 2);
        }
        out[key] = val;
    }
    return out;
}

namespace {
std::string env(const char* name) {
    const char* v = std::getenv(name);
    return v ? v : "(não definido)";
}
} // namespace

SystemInfo collectSystemInfo() {
    SystemInfo info;
    std::ifstream f("/etc/os-release");
    if (f) {
        auto m = parseOsRelease(f);
        info.osName = m.count("PRETTY_NAME") ? m["PRETTY_NAME"] : "Linux";
    } else {
        info.osName = "Linux (os-release ausente)";
    }
    utsname u{};
    if (uname(&u) == 0) {
        info.kernel = u.release;
        info.arch = u.machine;
    }
    info.sessionType = env("XDG_SESSION_TYPE");
    info.desktop = env("XDG_CURRENT_DESKTOP");
    return info;
}

} // namespace rlc
