#include <filesystem>
#include <fstream>
#include <sstream>

#include "check.hpp"
#include "core/logger.hpp"

int main() {
    using namespace rlc;
    const auto path = std::filesystem::temp_directory_path() / "rlc_test_logger" / "t.log";
    std::filesystem::remove_all(path.parent_path());

    auto& log = Logger::instance();
    log.setConsole(false);
    log.setLevel(LogLevel::Info);
    CHECK(log.open(path));
    logInfo("test", "olá {}", 42);
    logDebug("test", "nao deve aparecer");
    logError("test", "erro {}", "x");
    log.close();

    std::ifstream f(path);
    std::stringstream ss;
    ss << f.rdbuf();
    const std::string s = ss.str();
    CHECK(s.find("[INFO] [test] olá 42") != std::string::npos);
    CHECK(s.find("[ERROR] [test] erro x") != std::string::npos);
    CHECK(s.find("nao deve aparecer") == std::string::npos);
    std::filesystem::remove_all(path.parent_path());
    return 0;
}
