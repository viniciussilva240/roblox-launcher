#include <sstream>

#include "check.hpp"
#include "platform/linux/system_info.hpp"

int main() {
    using namespace rlc;
    std::istringstream in(
        "# comentario\nNAME=\"Ubuntu\"\nPRETTY_NAME=\"Ubuntu 26.04 LTS\"\nID=ubuntu\nlinha_ruim\n");
    auto m = parseOsRelease(in);
    CHECK(m["NAME"] == "Ubuntu");
    CHECK(m["PRETTY_NAME"] == "Ubuntu 26.04 LTS");
    CHECK(m["ID"] == "ubuntu");
    CHECK(m.count("linha_ruim") == 0);

    const auto info = collectSystemInfo();
    CHECK(!info.kernel.empty());
    CHECK(!info.arch.empty());
    return 0;
}
