# roblox-linux-client — Milestone 1

Aplicativo mínimo C++20 / CMake / SDL3 / Vulkan: abre janela, detecta GPU, grava logs.
**Ainda não executa Roblox.** As Fases 5-6 dependem de documentação pública que não existe
(protocolo e runtime do cliente são proprietários; só há a Open Cloud API oficial).

## Gerar o .deb
    ./packaging/build-deb.sh
    sudo apt install ./roblox-linux-client_0.1.0_amd64.deb

## Compilar manualmente (Debug + sanitizers)
    cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug -DRLC_SANITIZE=ON
    cmake --build build -j$(nproc) && ctest --test-dir build --output-on-failure

## Rodar
    rlc-client --keep-open      # Esc ou fechar a janela para sair
Log: ~/.local/state/roblox-linux-client/logs/client.log
