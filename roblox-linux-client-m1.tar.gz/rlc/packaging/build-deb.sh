#!/usr/bin/env bash
# Instala dependências, compila, testa e gera o .deb.
set -euo pipefail
cd "$(dirname "$0")/.."

VERSION="0.1.0"
ARCH="$(dpkg --print-architecture)"

echo ">> Instalando dependências (vai pedir sua senha)"
sudo apt-get update
sudo apt-get install -y build-essential cmake pkg-config dpkg-dev \
    libsdl3-dev libvulkan-dev vulkan-tools vulkan-validationlayers

echo ">> Compilando (Release)"
cmake -S . -B build-release -DCMAKE_BUILD_TYPE=Release
cmake --build build-release -j"$(nproc)"

echo ">> Rodando testes"
ctest --test-dir build-release --output-on-failure

echo ">> Montando pacote"
rm -rf pkg
DESTDIR="$PWD/pkg" cmake --install build-release --prefix /usr
mkdir -p pkg/DEBIAN

DEPS="$(ldd pkg/usr/bin/rlc-client | awk '/=>/ {print $3}' | xargs -r dpkg -S 2>/dev/null \
        | cut -d: -f1 | sort -u | paste -sd, - | sed 's/,/, /g' || true)"

cat > pkg/DEBIAN/control <<CTRL
Package: roblox-linux-client
Version: ${VERSION}
Section: utils
Priority: optional
Architecture: ${ARCH}
Depends: ${DEPS}
Maintainer: Vinicius <nobody@example.com>
Description: Cliente Linux experimental - Milestone 1
 Abre uma janela SDL3, inicializa Vulkan, detecta a GPU e grava logs.
 Ainda nao executa Roblox.
CTRL

OUT="roblox-linux-client_${VERSION}_${ARCH}.deb"
dpkg-deb --build --root-owner-group pkg "$OUT"
echo ">> Pronto: $PWD/$OUT"
echo "   Instalar: sudo apt install ./$OUT"
