# Roblox Linux

Launcher e diagnóstico para jogar Roblox no Linux. Ele detecta o seu sistema, instala o que faltar
(com a sua confirmação) e inicia o jogo. Você não precisa saber o que é Flatpak ou Sober.

## Instalação

    tar -xzf roblox-linux.tar.gz
    cd roblox-linux
    ./launcher

Funciona de qualquer pasta (Downloads, Desktop, pendrive). Não precisa de Python, Node.js ou Wine.

## Menu

    [1] Iniciar Roblox
    [2] Diagnóstico
    [3] Instalar/Reparar
    [4] Atualizar
    [5] Desinstalar
    [0] Sair

## Opções de linha de comando

    ./launcher --start        inicia o Roblox
    ./launcher --install      instala/configura
    ./launcher --repair       corrige problemas comuns
    ./launcher --diagnose     diagnóstico (termina com STATUS: PRONTO ou PROBLEMA DETECTADO)
    ./launcher --update       atualiza o Sober
    ./launcher --uninstall    desinstala
    ./launcher --debug        diagnóstico detalhado
    ./launcher --yes          responde "sim" às confirmações (os planos continuam sendo exibidos)

`install.sh`, `diagnose.sh`, `update.sh` e `uninstall.sh` são atalhos para as opções acima.

## Como funciona

O Roblox não tem cliente oficial para Linux e o cliente do Windows não roda no Wine por causa do
anti-cheat. A solução existente é o **Sober**, um projeto independente que executa o cliente Android
do Roblox. O Sober só é distribuído como **Flatpak, pelo Flathub**. Este projeto é somente a camada de
orquestração por cima disso:

1. Verifica arquitetura, distribuição, GPU, Vulkan, Flatpak, Flathub e Sober.
2. Se faltar o Flatpak, mostra o comando da sua distribuição (apt, dnf, pacman, zypper, xbps),
   explica o motivo e pede confirmação. É o único passo que usa sudo (instala no sistema).
3. Adiciona o Flathub oficial e instala o Sober **somente para o seu usuário** (`flatpak --user`, sem sudo).
4. Inicia o Sober. Na primeira execução ele baixa o Roblox dos servidores oficiais.

Nada do Roblox nem do Sober está dentro deste pacote. Nada é baixado de sites de terceiros.
O launcher não modifica o cliente, não faz engenharia reversa e não tenta contornar o Hyperion ou
qualquer proteção do Roblox.

## Requisitos

- Linux **x86_64** (ARM não é suportado: "Esta versão atualmente suporta somente sistemas Linux x86_64.")
- Sessão gráfica (Wayland ou X11) e uma GPU com driver que suporte Vulkan
- Internet e cerca de 3 GB livres
- Uma das distribuições: Ubuntu, Debian, Linux Mint, Pop!_OS, Fedora, Arch, Manjaro (e derivadas); openSUSE e Void
  têm suporte básico para instalar o Flatpak

## Logs

Ficam em `logs/` (um arquivo por dia). Se a pasta não for gravável (ex.: pendrive somente leitura), vão para
`~/.local/state/roblox-linux/logs`. Senhas, tokens e cookies nunca são tratados nem gravados.

## Configuração

`config/roblox-linux.conf`: escopo da instalação (`user` ou `system`), pasta de logs alternativa e
`SELF_UPDATE_URL`. O arquivo é lido como texto (não é executado) e os valores são validados.

## Atualização

`./launcher --update` atualiza o Sober pelo Flatpak. A atualização do próprio launcher só é verificada se
`SELF_UPDATE_URL` (https) estiver preenchida; ela só avisa que há versão nova, não baixa nem executa nada.
Hoje não existe fonte oficial configurada, então essa verificação fica desligada.

## Limitações e problemas conhecidos

- **O Sober não é apoiado pelo Roblox.** Uma mudança no servidor pode quebrá-lo a qualquer momento. Se isso
  acontecer, o launcher informa o erro e sugere atualizar; ele não tenta burlar nada.
- Sem GPU/Vulkan funcionando (por exemplo, máquina virtual sem aceleração) o jogo não roda bem. O launcher só
  informa como corrigir; **ele nunca altera drivers**.
- Se o botão "Jogar" do site não abrir o Sober, rode `./launcher --repair` (configura a associação de links) e
  confirme que o `xdg-desktop-portal` da sua área de trabalho está instalado.
- Depois de instalar o Flatpak pela primeira vez, pode ser preciso reiniciar a sessão para o Sober aparecer no
  menu de aplicativos. O `./launcher --start` funciona mesmo assim.
- O Roblox Studio não é coberto (existe outro projeto, o Vinegar).
- Se o Roblox mudar a forma de distribuição, este projeto precisará ser atualizado.

## Testes

Os testes ficam no repositório de desenvolvimento (`tests/run-tests.sh`), fora deste pacote. Eles simulam
Ubuntu, Debian, Mint, Pop!_OS, Fedora, Arch, Manjaro e openSUSE com arquivos `os-release` e gerenciadores de
pacotes/Flatpak falsos.

**Testes de distribuição foram realizados em ambiente simulado e não substituem testes em hardware real.**
O fluxo real com Flatpak, Flathub, Sober, GPU e Vulkan não foi exercitado nesses testes.

## Licença

MIT para os scripts deste projeto (veja `LICENSE`). Roblox e Sober têm licenças próprias e não fazem parte
deste pacote.
