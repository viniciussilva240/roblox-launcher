# lib/pkg.sh - gerenciador de pacotes (usado somente para instalar o Flatpak)

detect_pm() {
    PM=""
    case $DISTRO_FAMILY in
        debian) _order="apt-get dnf pacman zypper xbps-install";;
        fedora) _order="dnf zypper apt-get pacman xbps-install";;
        arch)   _order="pacman apt-get dnf zypper xbps-install";;
        suse)   _order="zypper dnf apt-get pacman xbps-install";;
        void)   _order="xbps-install apt-get dnf pacman zypper";;
        *)      _order="apt-get dnf pacman zypper xbps-install";;
    esac
    for _c in $_order; do
        if command -v "$_c" >/dev/null 2>&1; then PM=$_c; break; fi
    done
}

# Comandos (sem sudo) que instalam o Flatpak, um por linha.
pm_flatpak_plan() {
    case $PM in
        apt-get) printf '%s\n' "apt-get update" "apt-get install -y flatpak";;
        dnf) printf '%s\n' "dnf install -y flatpak";;
        pacman) printf '%s\n' "pacman -S --needed --noconfirm flatpak";;
        zypper) printf '%s\n' "zypper --non-interactive install flatpak";;
        xbps-install) printf '%s\n' "xbps-install -Sy flatpak";;
    esac
}

pm_install_flatpak() {
    _plan=$(pm_flatpak_plan)
    _oldifs=$IFS
    IFS='
'
    for _line in $_plan; do
        IFS=$_oldifs
        # shellcheck disable=SC2086
        if ! as_root $_line; then
            case $_line in
                "apt-get update") warn "'apt-get update' falhou; tentando instalar mesmo assim.";;
                *) IFS=$_oldifs; return 1;;
            esac
        fi
        IFS='
'
    done
    IFS=$_oldifs
    hash -r 2>/dev/null
    return 0
}

pm_fail_hint() {
    case $PM in
        apt-get) say "Dica: se o erro for 404/arquivo não encontrado, atualize a lista com: $(root_prefix)apt-get update";;
        dnf) say "Dica: se o erro for de metadados, tente: $(root_prefix)dnf makecache";;
        pacman) say "Dica: se o erro for 404, sincronize o sistema com: $(root_prefix)pacman -Syu";;
        zypper) say "Dica: tente atualizar os repositórios: $(root_prefix)zypper refresh";;
    esac
}
