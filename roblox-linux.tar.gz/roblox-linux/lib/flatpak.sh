# lib/flatpak.sh - funcoes sobre Flatpak/Flathub

fp_present() { command -v flatpak >/dev/null 2>&1; }

fp_version() { flatpak --version 2>/dev/null | head -n 1; }

fp_scope_init() {
    SCOPE_FLAG="--$INSTALL_SCOPE"
    if [ "$INSTALL_SCOPE" = system ]; then SCOPE_DESC="sistema inteiro (exige administrador)"
    else SCOPE_DESC="somente para o seu usuário (flatpak --user, sem sudo)"; fi
}

# fp_remote_in user|system -> 0 se o Flathub existir nesse escopo
fp_remote_in() {
    flatpak remotes "--$1" --columns=name 2>/dev/null | grep -qx "$FLATHUB_REMOTE_NAME"
}

# fp_exec user|system args... -> executa flatpak no escopo (root se for system)
fp_exec() {
    _fs=$1; shift
    if [ "$_fs" = system ]; then as_root flatpak "$@"; else run_logged flatpak "$@"; fi
}
