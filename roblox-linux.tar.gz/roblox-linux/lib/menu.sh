# lib/menu.sh - modo interativo

menu_pause() {
    printf '\nPressione Enter para voltar ao menu...'
    read -r _x || true
    printf '\n'
}

preflight_quick() {
    detect_distro; detect_pm; detect_session
    _need=""
    if ! fp_present; then
        say "Flatpak não está instalado."; _need=1
    else
        if ! fp_remote_in "$INSTALL_SCOPE" && ! fp_remote_in user && ! fp_remote_in system; then
            say "O repositório Flathub não está configurado."; _need=1
        fi
        if ! sober_installed; then
            say "Roblox Linux ainda não está instalado."; _need=1
        fi
    fi
    if [ -z "$_need" ]; then
        say "Roblox está pronto para ser iniciado."
        return 0
    fi
    say ""
    if confirm "Deseja instalar/configurar agora?"; then
        cmd_install
    else
        say "Você pode fazer isso depois pela opção [3] do menu."
    fi
    return 0
}

cmd_interactive() {
    if [ ! -t 0 ]; then
        err "Nenhum terminal interativo detectado. Use ./launcher --help para ver as opções (por exemplo ./launcher --start)."
        return 2
    fi
    banner "ROBLOX LINUX"
    printf '\n'
    preflight_quick
    while :; do
        printf '\n'
        banner "ROBLOX LINUX"
        printf '\n[1] Iniciar Roblox\n[2] Diagnóstico\n[3] Instalar/Reparar\n[4] Atualizar\n[5] Desinstalar\n[0] Sair\n\nEscolha: '
        if ! read -r _opt; then printf '\n'; break; fi
        printf '\n'
        case $_opt in
            1) cmd_start;;
            2) cmd_diagnose;;
            3) cmd_repair;;
            4) cmd_update;;
            5) cmd_uninstall; [ "$RL_REMOVED_SELF" = 1 ] && return 0;;
            0|q|Q) break;;
            *) say "Opção inválida.";;
        esac
        menu_pause
    done
    return 0
}
