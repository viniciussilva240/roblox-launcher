# lib/sober.sh - funcoes sobre o Sober (dependencia externa, instalada pelo Flathub)

sober_installed() { fp_present && flatpak info "$SOBER_APP_ID" >/dev/null 2>&1; }

# imprime user|system|"" conforme onde o Sober esta instalado
sober_scope() {
    if flatpak info --user "$SOBER_APP_ID" >/dev/null 2>&1; then printf 'user'
    elif flatpak info --system "$SOBER_APP_ID" >/dev/null 2>&1; then printf 'system'
    fi
}

sober_version() {
    flatpak info "$SOBER_APP_ID" 2>/dev/null | sed -n 's/^[[:space:]]*Version:[[:space:]]*//p' | head -n 1
}

# sober_update_pending user|system -> 0 se houver atualizacao
sober_update_pending() {
    flatpak remote-ls "--$1" --updates --columns=application 2>/dev/null | grep -qx "$SOBER_APP_ID"
}
