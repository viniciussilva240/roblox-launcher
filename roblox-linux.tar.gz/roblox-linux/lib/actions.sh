# lib/actions.sh - instalar, reparar, iniciar, atualizar, desinstalar

# ------------------------------------------------------------------ Flatpak
ensure_flatpak() {
    if fp_present; then
        say "Flatpak: OK ($(fp_version))"
        return 0
    fi
    say "Flatpak não está instalado."
    if [ -z "$PM" ]; then
        err "Não foi possível identificar o gerenciador de pacotes da sua distribuição ($DISTRO_PRETTY)."
        say "Instale o Flatpak seguindo as instruções oficiais: https://flatpak.org/setup/"
        return 1
    fi
    say ""
    plan_line "Distribuição:" "$DISTRO_PRETTY (família: $DISTRO_FAMILY)"
    plan_line "Motivo:" "o Sober (Roblox no Linux) é distribuído somente como Flatpak."
    plan_line "Origem:" "repositórios oficiais da sua distribuição (via $PM)"
    if is_root; then plan_line "Escopo:" "sistema inteiro (você já é administrador)"
    else plan_line "Escopo:" "sistema inteiro; pede sua senha de administrador (sudo)"; fi
    plan_line "Comandos:" ""
    _pfx=$(root_prefix)
    pm_flatpak_plan | while IFS= read -r _l; do printf '    %s%s\n' "$_pfx" "$_l"; done
    say ""
    if ! confirm "Instalar o Flatpak agora?"; then
        say "Instalação do Flatpak cancelada."
        return 1
    fi
    if ! pm_install_flatpak || ! fp_present; then
        err "Não foi possível instalar o Flatpak."
        pm_fail_hint
        say "Log: $RL_LOG_FILE"
        return 1
    fi
    say "Flatpak instalado: $(fp_version)"
    say "Observação: em alguns sistemas é preciso encerrar a sessão e entrar de novo para o Flatpak aparecer no menu de aplicativos."
    return 0
}

ensure_flathub() {
    if fp_remote_in "$INSTALL_SCOPE"; then
        say "Flathub: OK ($INSTALL_SCOPE)"
        return 0
    fi
    say "O repositório Flathub não está configurado."
    say ""
    plan_line "Motivo:" "o Flathub é a fonte oficial do Sober."
    plan_line "Origem:" "$FLATHUB_REPO_URL"
    plan_line "Escopo:" "$SCOPE_DESC"
    if [ "$INSTALL_SCOPE" = system ]; then _pfx=$(root_prefix); else _pfx=""; fi
    plan_line "Comando:" "${_pfx}flatpak remote-add $SCOPE_FLAG --if-not-exists $FLATHUB_REMOTE_NAME $FLATHUB_REPO_URL"
    say ""
    if ! confirm "Adicionar o Flathub agora?"; then
        say "Configuração do Flathub cancelada."
        return 1
    fi
    if ! fp_exec "$INSTALL_SCOPE" remote-add "$SCOPE_FLAG" --if-not-exists "$FLATHUB_REMOTE_NAME" "$FLATHUB_REPO_URL"; then
        err "Não foi possível adicionar o Flathub. Verifique sua conexão com a internet."
        say "Log: $RL_LOG_FILE"
        return 1
    fi
    say "Flathub configurado."
    return 0
}

ensure_sober() {
    if sober_installed; then
        say "Sober: INSTALADO ($(sober_scope))"
        return 0
    fi
    say "Roblox Linux ainda não está instalado."
    say "Será instalado através do Flathub oficial."
    say ""
    plan_line "Pacote:" "$SOBER_APP_ID (Sober, camada de execução de terceiros para o Roblox)"
    plan_line "Origem:" "Flathub (https://flathub.org/apps/$SOBER_APP_ID)"
    plan_line "Escopo:" "$SCOPE_DESC"
    if [ "$INSTALL_SCOPE" = system ]; then _pfx=$(root_prefix); else _pfx=""; fi
    plan_line "Comando:" "${_pfx}flatpak install $SCOPE_FLAG -y $FLATHUB_REMOTE_NAME $SOBER_APP_ID"
    plan_line "Observação:" "o Sober é independente e não tem apoio do Roblox. Na primeira execução ele baixa o Roblox dos servidores oficiais."
    say ""
    if ! confirm "Instalar agora?"; then
        say "Instalação cancelada."
        return 1
    fi
    if ! fp_exec "$INSTALL_SCOPE" install "$SCOPE_FLAG" -y "$FLATHUB_REMOTE_NAME" "$SOBER_APP_ID" || ! sober_installed; then
        err "Não foi possível instalar o Sober."
        say "Verifique a conexão com a internet e o espaço em disco; depois rode: ./launcher --repair"
        say "Log: $RL_LOG_FILE"
        return 1
    fi
    say "Sober instalado."
    return 0
}

# ------------------------------------------------------------------ integracao
offer_integration() {
    # Atalho no menu de aplicativos
    _apps="${XDG_DATA_HOME:-${HOME:-.}/.local/share}/applications"
    _desk="$_apps/roblox-linux.desktop"
    if [ ! -f "$_desk" ] && [ -f "$RL_ROOT/assets/roblox-linux.desktop.in" ]; then
        say ""
        say "Atalho no menu de aplicativos:"
        plan_line "Arquivo:" "$_desk"
        plan_line "Aponta para:" "$RL_ROOT/launcher (se esta pasta for movida, o atalho deixa de funcionar)"
        if confirm "Criar o atalho?"; then
            if mkdir -p "$_apps" && L="$RL_ROOT/launcher" awk '{i=index($0,"@LAUNCHER@"); if(i){$0=substr($0,1,i-1) "\"" ENVIRON["L"] "\"" substr($0,i+10)} print}' "$RL_ROOT/assets/roblox-linux.desktop.in" > "$_desk"; then
                say "Atalho criado."
            else
                warn "Não foi possível criar o atalho."
            fi
        fi
    fi
    # Links roblox-player:// do navegador -> Sober
    if command -v xdg-mime >/dev/null 2>&1 && sober_installed; then
        _cur=$(xdg-mime query default x-scheme-handler/roblox-player 2>/dev/null)
        if [ "$_cur" != "$SOBER_APP_ID.desktop" ]; then
            say ""
            say "Login e início de jogos pelo navegador:"
            plan_line "Motivo:" "para o botão Jogar do site do Roblox abrir o Sober."
            plan_line "Comando:" "xdg-mime default $SOBER_APP_ID.desktop x-scheme-handler/roblox-player"
            plan_line "Efeito:" "altera apenas as associações de links do seu usuário"
            if confirm "Configurar agora?"; then
                if run_logged xdg-mime default "$SOBER_APP_ID.desktop" x-scheme-handler/roblox-player; then
                    say "Associação configurada."
                else
                    warn "Não foi possível configurar a associação de links."
                fi
            fi
        fi
    fi
}

# ------------------------------------------------------------------ instalar / reparar
cmd_install() {
    detect_distro; detect_pm; detect_session
    say "Verificando o sistema: $DISTRO_PRETTY, $RL_ARCH."
    ensure_flatpak || return 4
    ensure_flathub || return 4
    ensure_sober || return 4
    offer_integration
    say ""
    say "Roblox está pronto para ser iniciado."
    say "Para jogar: ./launcher --start"
    return 0
}

repair_permissions() {
    is_root && return 0
    _me=$(id -un)
    for _pd in "${XDG_DATA_HOME:-${HOME:-.}/.local/share}/flatpak" "${HOME:-.}/.var/app/$SOBER_APP_ID"; do
        [ -e "$_pd" ] || continue
        _bad=$(find "$_pd" ! -user "$_me" 2>/dev/null | head -n 1)
        if [ -n "$_bad" ]; then
            say ""
            say "Problema de permissões: há arquivos em $_pd que não pertencem ao seu usuário (por exemplo: $_bad)."
            say "Isso costuma acontecer quando o Flatpak foi usado antes com sudo."
            plan_line "Comando:" "$(root_prefix)chown -R $_me $_pd"
            if confirm "Corrigir o dono desses arquivos agora?"; then
                as_root chown -R "$_me" "$_pd" || warn "Não foi possível corrigir as permissões em $_pd."
            fi
        fi
    done
}

cmd_repair() {
    detect_distro; detect_pm; detect_session; detect_gpu; detect_vulkan
    say "Verificando e reparando a instalação..."
    ensure_flatpak || return 4
    ensure_flathub || return 4
    ensure_sober || return 4
    repair_permissions
    _sc=$(sober_scope)
    if [ -n "$_sc" ]; then
        say ""
        say "Verificação de integridade do Flatpak:"
        plan_line "Comando:" "flatpak repair --$_sc"
        if confirm "Executar agora?"; then
            fp_exec "$_sc" repair "--$_sc" || warn "'flatpak repair' terminou com erro; veja o log."
        fi
        if sober_update_pending "$_sc"; then
            say ""
            say "Há uma atualização pendente do Sober."
            plan_line "Comando:" "flatpak update --$_sc -y $SOBER_APP_ID"
            if confirm "Atualizar agora?"; then
                fp_exec "$_sc" update "--$_sc" -y "$SOBER_APP_ID" || warn "A atualização falhou; veja o log."
            fi
        fi
    fi
    offer_integration
    # GPU/Vulkan: somente informar
    _gp=0
    case $VULKAN_STATE in
        fail|none|software)
            _gp=1
            say ""
            say "Atenção (GPU/Vulkan): o launcher não altera drivers. Detalhes e como corrigir:"
            say "  $(vulkan_fix_hint)";;
    esac
    say ""
    if sober_installed; then
        say "Reparação concluída. Confira o estado com: ./launcher --diagnose"
        [ "$_gp" = 0 ] || say "Há um aviso de GPU/Vulkan acima que pode afetar o desempenho."
        return 0
    fi
    return 4
}

# ------------------------------------------------------------------ iniciar
cmd_start() {
    detect_distro; detect_pm; detect_session
    if ! fp_present || ! sober_installed; then
        say "Roblox Linux ainda não está instalado."
        if confirm "Deseja instalar agora?"; then
            cmd_install || return 4
        else
            say "Use ./launcher --install quando quiser instalar."
            return 4
        fi
    fi
    if [ "$HAS_DISPLAY" != 1 ]; then
        err "Nenhuma sessão gráfica detectada (DISPLAY/WAYLAND_DISPLAY vazios). Abra o launcher em um terminal dentro do ambiente gráfico."
        return 1
    fi
    say "Iniciando o Roblox (Sober)... Feche a janela do jogo para voltar."
    run_logged flatpak run "$SOBER_APP_ID"
    _src=$?
    if [ "$_src" -ne 0 ]; then
        err "O Sober terminou com erro (código $_src)."
        say "Últimas linhas do log ($RL_LOG_FILE):"
        tail -n 15 "$RL_LOG_FILE" 2>/dev/null | sed 's/^/  | /'
        _sc=$(sober_scope)
        if [ -n "$_sc" ] && sober_update_pending "$_sc"; then
            say "Há uma atualização do Sober disponível; ela pode corrigir o problema. Rode: ./launcher --update"
        else
            say "Se o problema começou de repente, o Roblox pode ter mudado algo no servidor e o Sober precisar de uma atualização."
            say "Este launcher não tenta contornar nenhuma proteção do Roblox. Rode ./launcher --diagnose e ./launcher --repair."
        fi
        return 1
    fi
    say "Sessão encerrada normalmente."
    return 0
}

# ------------------------------------------------------------------ atualizar
self_update_check() {
    if [ -z "$SELF_UPDATE_URL" ]; then
        say "Launcher: versão $RL_VERSION. Nenhuma fonte de atualização configurada (SELF_UPDATE_URL em config/roblox-linux.conf); verificação ignorada."
        return 0
    fi
    _vf=$(mktemp "${TMPDIR:-/tmp}/roblox-linux.XXXXXX" 2>/dev/null) || return 0
    _got=1
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL --max-time 20 --proto '=https' --tlsv1.2 "$SELF_UPDATE_URL/VERSION" -o "$_vf" 2>/dev/null && _got=0
    elif command -v wget >/dev/null 2>&1; then
        wget -q -T 20 --https-only -O "$_vf" "$SELF_UPDATE_URL/VERSION" 2>/dev/null && _got=0
    fi
    _nv=$(head -n 1 "$_vf" 2>/dev/null | tr -d '[:space:]'); rm -f "$_vf"
    case $_nv in
        ''|*[!0-9.]*) _got=1;;
    esac
    if [ "$_got" -ne 0 ]; then
        warn "Não foi possível verificar a versão do launcher em $SELF_UPDATE_URL."
        return 0
    fi
    if ver_gt "$_nv" "$RL_VERSION"; then
        say "Nova versão do launcher disponível: $_nv (atual: $RL_VERSION)."
        say "Baixe manualmente: $SELF_UPDATE_URL/roblox-linux.tar.gz (nada é executado automaticamente)."
    else
        say "Launcher: versão $RL_VERSION (atualizado)."
    fi
}

cmd_update() {
    detect_distro; detect_pm
    _rc=0
    if ! fp_present; then
        err "Flatpak não está instalado. Rode: ./launcher --install"
        _rc=4
    else
        _sc=$(sober_scope)
        if [ -z "$_sc" ]; then
            say "Roblox Linux (Sober) ainda não está instalado. Rode: ./launcher --install"
            _rc=4
        else
            say "Atualizando o Sober via Flatpak (origem: Flathub)."
            if [ "$_sc" = system ]; then _pfx=$(root_prefix); else _pfx=""; fi
            plan_line "Comando:" "${_pfx}flatpak update --$_sc -y $SOBER_APP_ID"
            if confirm "Atualizar agora?"; then
                if fp_exec "$_sc" update "--$_sc" -y "$SOBER_APP_ID"; then
                    say "Sober atualizado (ou já estava na versão mais recente)."
                else
                    err "A atualização falhou. Verifique a internet e rode ./launcher --repair"
                    _rc=1
                fi
            else
                say "Atualização cancelada."
            fi
        fi
    fi
    self_update_check
    return "$_rc"
}

# ------------------------------------------------------------------ desinstalar
safe_to_remove_dir() { # $1 = pasta do launcher
    [ -n "$1" ] || return 1
    [ -d "$1" ] || return 1
    case $1 in /|.|..) return 1;; esac
    [ "$1" != "${HOME:-}" ] || return 1
    [ -f "$1/launcher" ] && [ -f "$1/VERSION" ] && [ -f "$1/config/roblox-linux.conf" ] && [ -d "$1/lib" ]
}

cmd_uninstall() {
    detect_distro
    say "Desinstalar Roblox Linux"
    say ""
    say "O que deseja remover?"
    say "[1] Remover somente o launcher (esta pasta, atalho do menu e logs)"
    say "[2] Remover launcher + Sober"
    say "[3] Cancelar"
    say ""
    say "O Flatpak, o Flathub e os pacotes do sistema NÃO serão removidos."
    printf 'Escolha: '
    if ! read -r _uopt; then printf '\n'; say "Cancelado."; return 0; fi
    log_line INFO "uninstall: opção $_uopt"
    case $_uopt in
        1|2) ;;
        *) say "Cancelado. Nada foi removido."; return 0;;
    esac

    if [ "$_uopt" = 2 ]; then
        if ! fp_present || [ -z "$(sober_scope)" ]; then
            say "O Sober não está instalado; nada a remover nessa parte."
        else
            _sc=$(sober_scope)
            say ""
            plan_line "Remover:" "$SOBER_APP_ID (escopo: $_sc)"
            if [ "$_sc" = system ]; then _pfx=$(root_prefix); else _pfx=""; fi
            plan_line "Comando:" "${_pfx}flatpak uninstall --$_sc -y $SOBER_APP_ID"
            if confirm "Remover o Sober?"; then
                _del=""
                say "Os dados do Sober (configurações e o Roblox baixado) ficam em ~/.var/app/$SOBER_APP_ID."
                if confirm "Remover também esses dados?"; then _del="--delete-data"; fi
                # shellcheck disable=SC2086
                if fp_exec "$_sc" uninstall "--$_sc" -y $_del "$SOBER_APP_ID"; then say "Sober removido."
                else err "Não foi possível remover o Sober."; fi
            else
                say "Sober mantido."
            fi
        fi
    fi

    say ""
    _desk="${XDG_DATA_HOME:-${HOME:-.}/.local/share}/applications/roblox-linux.desktop"
    if [ -f "$_desk" ]; then
        if rm -f "$_desk"; then say "Atalho do menu removido: $_desk"; fi
    fi
    _fb="${XDG_STATE_HOME:-${HOME:-.}/.local/state}/$LOG_DIR_FALLBACK_SUBDIR"
    if [ -d "$_fb" ]; then
        rm -rf "$_fb" && say "Logs removidos: $_fb"
        rmdir "$(dirname "$_fb")" 2>/dev/null
    fi

    if safe_to_remove_dir "$RL_ROOT"; then
        plan_line "Pasta do launcher:" "$RL_ROOT"
        if confirm "Apagar esta pasta agora?"; then
            if rm -rf "$RL_ROOT"; then
                RL_REMOVED_SELF=1
                printf 'Pasta removida. Roblox Linux desinstalado.\n'
            else
                err "Não foi possível apagar $RL_ROOT. Apague manualmente."
                return 1
            fi
        else
            say "Pasta mantida: $RL_ROOT"
        fi
    else
        warn "Por segurança, a pasta $RL_ROOT não será apagada automaticamente. Apague-a manualmente."
    fi
    return 0
}
