# lib/detect.sh - deteccao de sistema, GPU, Vulkan etc. (POSIX sh)
# Variaveis de teste (nao use em producao): RL_UNAME_M, RL_OS_RELEASE, RL_DRM_DIR.

detect_platform() {
    RL_OS=$(uname -s 2>/dev/null || echo desconhecido)
    RL_KERNEL=$(uname -r 2>/dev/null || echo desconhecido)
    RL_ARCH=${RL_UNAME_M:-$(uname -m 2>/dev/null || echo desconhecido)}
}

check_platform_or_exit() {
    detect_platform
    if [ "$RL_OS" != Linux ]; then
        err "Sistema operacional detectado: $RL_OS. Esta ferramenta funciona somente em Linux."
        exit 3
    fi
    case $RL_ARCH in
        x86_64|amd64) ;;
        *)
            err "Arquitetura detectada: $RL_ARCH."
            err "Esta versão atualmente suporta somente sistemas Linux x86_64."
            exit 3
            ;;
    esac
}

osr_get() {
    [ -r "$RL_OSR_FILE" ] || return 0
    sed -n "s/^$1=//p" "$RL_OSR_FILE" | head -n 1 | sed "s/^\"\(.*\)\"\$/\1/; s/^'\(.*\)'\$/\1/"
}

detect_distro() {
    if [ -n "${RL_OS_RELEASE:-}" ]; then RL_OSR_FILE=$RL_OS_RELEASE
    elif [ -r /etc/os-release ]; then RL_OSR_FILE=/etc/os-release
    else RL_OSR_FILE=/usr/lib/os-release; fi
    DISTRO_ID=$(osr_get ID)
    DISTRO_LIKE=$(osr_get ID_LIKE)
    DISTRO_VERSION=$(osr_get VERSION_ID)
    DISTRO_PRETTY=$(osr_get PRETTY_NAME)
    [ -n "$DISTRO_ID" ] || DISTRO_ID=desconhecida
    [ -n "$DISTRO_PRETTY" ] || DISTRO_PRETTY="Linux (distribuição não identificada)"
    DISTRO_FAMILY=desconhecida
    for _w in $DISTRO_ID $DISTRO_LIKE; do
        case $_w in
            debian|ubuntu|linuxmint|pop|raspbian|elementary|zorin|kali|neon) DISTRO_FAMILY=debian; break;;
            fedora|rhel|centos|rocky|almalinux|nobara|bazzite) DISTRO_FAMILY=fedora; break;;
            arch|manjaro|endeavouros|garuda|cachyos|artix) DISTRO_FAMILY=arch; break;;
            suse|opensuse*|sles) DISTRO_FAMILY=suse; break;;
            void) DISTRO_FAMILY=void; break;;
        esac
    done
}

detect_cpu() {
    CPU_MODEL=$(sed -n 's/^model name[[:space:]]*:[[:space:]]*//p' /proc/cpuinfo 2>/dev/null | head -n 1)
    [ -n "$CPU_MODEL" ] || CPU_MODEL="não identificada"
    CPU_THREADS=$(grep -c '^processor' /proc/cpuinfo 2>/dev/null || echo "?")
}

detect_mem() {
    MEM_KB=$(awk '/^MemTotal:/ {print $2}' /proc/meminfo 2>/dev/null)
    [ -n "$MEM_KB" ] || MEM_KB=0
    MEM_HUMAN=$(awk -v k="$MEM_KB" 'BEGIN{printf "%.1f GB", k/1048576}')
}

detect_disk() {
    DISK_DIR=${HOME:-.}
    DISK_FREE_KB=$(df -Pk "$DISK_DIR" 2>/dev/null | awk 'NR==2 {print $4}')
    [ -n "$DISK_FREE_KB" ] || DISK_FREE_KB=0
    DISK_FREE_HUMAN=$(awk -v k="$DISK_FREE_KB" 'BEGIN{printf "%.1f GB", k/1048576}')
}

detect_session() {
    SESSION_TYPE=${XDG_SESSION_TYPE:-}
    if [ -z "$SESSION_TYPE" ]; then
        if [ -n "${WAYLAND_DISPLAY:-}" ]; then SESSION_TYPE=wayland
        elif [ -n "${DISPLAY:-}" ]; then SESSION_TYPE=x11
        else SESSION_TYPE=nenhuma; fi
    fi
    case $SESSION_TYPE in
        wayland) SESSION_LABEL=Wayland;;
        x11) SESSION_LABEL=X11;;
        tty) SESSION_LABEL="console (sem ambiente gráfico)";;
        nenhuma) SESSION_LABEL="nenhuma sessão gráfica detectada";;
        *) SESSION_LABEL=$SESSION_TYPE;;
    esac
    SESSION_DESKTOP=${XDG_CURRENT_DESKTOP:-desconhecido}
    if [ -n "${WAYLAND_DISPLAY:-}${DISPLAY:-}" ]; then HAS_DISPLAY=1; else HAS_DISPLAY=0; fi
}

gpu_driver_label() { # $1=driver
    case $1 in
        nvidia)
            _nv=$(sed -n 's/.*Kernel Module[[:space:]]*\([0-9][0-9.]*\).*/\1/p' /proc/driver/nvidia/version 2>/dev/null | head -n 1)
            printf 'NVIDIA proprietário%s' "${_nv:+ $_nv}";;
        nouveau) printf 'nouveau (código aberto, Mesa)';;
        amdgpu|radeon|i915|xe) printf 'Mesa (%s)' "$1";;
        '') printf 'não identificado';;
        *) printf '%s' "$1";;
    esac
}

detect_gpu() {
    GPU_LIST=""; GPU_COUNT=0; GPU_NVIDIA_DRIVER=""
    _drm=${RL_DRM_DIR:-/sys/class/drm}
    for _d in "$_drm"/card[0-9]*; do
        [ -d "$_d" ] || continue
        case ${_d##*/} in card*-*) continue;; esac
        [ -r "$_d/device/vendor" ] || continue
        _vid=$(cat "$_d/device/vendor" 2>/dev/null)
        case $_vid in
            0x10de) _vendor=NVIDIA;;
            0x1002) _vendor=AMD;;
            0x8086) _vendor=Intel;;
            0x1af4|0x15ad|0x1234|0x1b36) _vendor=Virtual;;
            *) _vendor="Desconhecido ($_vid)";;
        esac
        _drv=""
        if [ -L "$_d/device/driver" ]; then _drv=${_d:+$(basename "$(readlink "$_d/device/driver")")}; fi
        _slot=$(basename "$(readlink -f "$_d/device" 2>/dev/null || echo x)")
        _name=""
        if command -v lspci >/dev/null 2>&1; then
            _name=$(lspci -s "$_slot" 2>/dev/null | head -n 1 | sed 's/^[^ ]* [^:]*: //')
        fi
        [ -n "$_name" ] || _name="GPU $_vendor (nome indisponível; instale pciutils)"
        [ "$_vendor" = NVIDIA ] && GPU_NVIDIA_DRIVER=$_drv
        GPU_COUNT=$((GPU_COUNT + 1))
        GPU_LIST="${GPU_LIST}${GPU_LIST:+
}$_vendor|$_drv|$_name"
    done
    if [ "$GPU_COUNT" -eq 0 ] && command -v lspci >/dev/null 2>&1; then
        _l=$(lspci 2>/dev/null | grep -Ei 'vga compatible|3d controller|display controller')
        _oldifs=$IFS
        IFS='
'
        for _line in $_l; do
            IFS=$_oldifs
            _name=$(printf '%s' "$_line" | sed 's/^[^ ]* [^:]*: //')
            case $_name in
                *NVIDIA*) _vendor=NVIDIA;;
                *AMD*|*ATI*|*Advanced\ Micro*) _vendor=AMD;;
                *Intel*) _vendor=Intel;;
                *) _vendor=Desconhecido;;
            esac
            GPU_COUNT=$((GPU_COUNT + 1))
            GPU_LIST="${GPU_LIST}${GPU_LIST:+
}$_vendor||$_name"
            IFS='
'
        done
        IFS=$_oldifs
    fi
}

detect_vulkan() {
    VULKAN_STATE=none; VULKAN_DETAIL=""
    if command -v vulkaninfo >/dev/null 2>&1; then
        _vo=$(vulkaninfo --summary 2>&1); _vrc=$?
        VULKAN_RAW=$_vo
        if [ "$_vrc" -ne 0 ]; then
            VULKAN_STATE=fail
        else
            _names=$(printf '%s\n' "$_vo" | sed -n 's/^[[:space:]]*deviceName[[:space:]]*=[[:space:]]*//p')
            if [ -z "$_names" ]; then
                VULKAN_STATE=fail
            elif [ -z "$(printf '%s\n' "$_names" | grep -vi 'llvmpipe\|lavapipe\|software')" ]; then
                VULKAN_STATE=software; VULKAN_DETAIL=$_names
            else
                VULKAN_STATE=ok; VULKAN_DETAIL=$(printf '%s\n' "$_names" | head -n 1)
            fi
        fi
        return 0
    fi
    for _vd in /usr/share/vulkan/icd.d /etc/vulkan/icd.d "${HOME:-.}/.local/share/vulkan/icd.d"; do
        if [ -d "$_vd" ] && [ -n "$(ls "$_vd" 2>/dev/null)" ]; then VULKAN_STATE=icd; return 0; fi
    done
}

vulkan_fix_hint() {
    case $DISTRO_FAMILY in
        debian) printf 'Exemplo: sudo apt-get install mesa-vulkan-drivers vulkan-tools (AMD/Intel). Para NVIDIA, instale o driver proprietário (no Ubuntu: sudo ubuntu-drivers install).';;
        fedora) printf 'Exemplo: sudo dnf install mesa-vulkan-drivers vulkan-tools (AMD/Intel). Para NVIDIA, instale o driver proprietário (RPM Fusion).';;
        arch) printf 'Exemplo: sudo pacman -S vulkan-icd-loader vulkan-tools mais vulkan-radeon (AMD), vulkan-intel (Intel) ou nvidia-utils (NVIDIA).';;
        suse) printf 'Exemplo: sudo zypper install libvulkan1 vulkan-tools (e libvulkan_radeon ou libvulkan_intel). Para NVIDIA, use o driver oficial da NVIDIA.';;
        *) printf 'Instale os drivers Vulkan da sua GPU e a ferramenta vulkan-tools usando o gerenciador de pacotes da sua distribuição.';;
    esac
}

detect_all() {
    detect_platform; detect_distro; detect_pm; detect_cpu; detect_mem
    detect_disk; detect_session; detect_gpu; detect_vulkan
}
