# lib/common.sh - utilidades comuns (POSIX sh). Carregue com: . "$RL_ROOT/lib/common.sh"

RL_DEBUG=${RL_DEBUG:-0}
RL_ASSUME_YES=${RL_ASSUME_YES:-0}
RL_LOG_FILE=/dev/null
RL_REMOVED_SELF=0

# Le CHAVE="valor" do arquivo de configuracao sem executa-lo.
conf_get() {
    _cv=$(sed -n "s/^$1=\"\([^\"]*\)\".*/\1/p" "$RL_ROOT/config/roblox-linux.conf" 2>/dev/null | head -n 1)
    if [ -n "$_cv" ]; then printf '%s' "$_cv"; else printf '%s' "$2"; fi
}

rl_load_config() {
    RL_VERSION=$(head -n 1 "$RL_ROOT/VERSION" 2>/dev/null)
    [ -n "$RL_VERSION" ] || RL_VERSION=desconhecida
    SOBER_APP_ID=$(conf_get SOBER_APP_ID "org.vinegarhq.Sober")
    FLATHUB_REMOTE_NAME=$(conf_get FLATHUB_REMOTE_NAME "flathub")
    FLATHUB_REPO_URL=$(conf_get FLATHUB_REPO_URL "https://dl.flathub.org/repo/flathub.flatpakrepo")
    INSTALL_SCOPE=$(conf_get INSTALL_SCOPE "user")
    LOG_DIR_FALLBACK_SUBDIR=$(conf_get LOG_DIR_FALLBACK_SUBDIR "roblox-linux/logs")
    SELF_UPDATE_URL=$(conf_get SELF_UPDATE_URL "")

    case $SOBER_APP_ID in ''|*[!A-Za-z0-9_.-]*) cfg_invalid SOBER_APP_ID;; esac
    case $FLATHUB_REMOTE_NAME in ''|*[!A-Za-z0-9_.-]*) cfg_invalid FLATHUB_REMOTE_NAME;; esac
    case $FLATHUB_REPO_URL in https://*) ;; *) cfg_invalid FLATHUB_REPO_URL;; esac
    case $FLATHUB_REPO_URL in *[!A-Za-z0-9:/._?=\&%~+-]*) cfg_invalid FLATHUB_REPO_URL;; esac
    case $INSTALL_SCOPE in user|system) ;; *) cfg_invalid INSTALL_SCOPE;; esac
    case $LOG_DIR_FALLBACK_SUBDIR in /*|*..*|'') cfg_invalid LOG_DIR_FALLBACK_SUBDIR;; esac
    case $SELF_UPDATE_URL in ''|https://*) ;; *) cfg_invalid SELF_UPDATE_URL;; esac
}

cfg_invalid() {
    printf 'ERRO: valor inválido para %s em config/roblox-linux.conf.\n' "$1" >&2
    exit 1
}

# ---- logs -------------------------------------------------------------------
rl_init_log() {
    _ld=${RL_LOG_DIR:-"$RL_ROOT/logs"}
    if ! { mkdir -p "$_ld" 2>/dev/null && [ -w "$_ld" ]; }; then
        _ld="${XDG_STATE_HOME:-${HOME:-/tmp}/.local/state}/$LOG_DIR_FALLBACK_SUBDIR"
        mkdir -p "$_ld" 2>/dev/null
    fi
    RL_LOG_DIR_USED=$_ld
    RL_LOG_FILE="$_ld/roblox-linux-$(date +%Y%m%d).log"
    if ! : >> "$RL_LOG_FILE" 2>/dev/null; then
        printf 'AVISO: não foi possível gravar logs em %s\n' "$_ld" >&2
        RL_LOG_FILE=/dev/null
    fi
    log_line INFO "--- Roblox Linux $RL_VERSION iniciado (args: ${RL_ARGS:-nenhum}) ---"
}

log_line() {
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" "$2" >> "$RL_LOG_FILE" 2>/dev/null
}

say()  { printf '%s\n' "$*"; log_line INFO "$*"; }
warn() { printf 'AVISO: %s\n' "$*" >&2; log_line WARN "$*"; }
err()  { printf 'ERRO: %s\n' "$*" >&2; log_line ERROR "$*"; }
dbg()  {
    log_line DEBUG "$*"
    if [ "$RL_DEBUG" = 1 ]; then printf '[debug] %s\n' "$*"; fi
}

# ---- interface ----------------------------------------------------------------
banner() {
    _bt=$1
    _bl=${#_bt}
    _bp=$(( (40 - _bl) / 2 ))
    [ "$_bp" -ge 0 ] || _bp=0
    _bs=""
    while [ "$_bp" -gt 0 ]; do _bs="$_bs "; _bp=$((_bp - 1)); done
    printf '========================================\n'
    printf '%s%s\n' "$_bs" "$_bt"
    printf '========================================\n'
}

plan_line() { printf '  %-15s %s\n' "$1" "$2"; }

# confirm "pergunta" -> 0 se o usuario respondeu sim
confirm() {
    if [ "$RL_ASSUME_YES" = 1 ]; then
        printf '%s [s/N]: s (--yes)\n' "$1"
        log_line INFO "confirmado via --yes: $1"
        return 0
    fi
    printf '%s [s/N]: ' "$1"
    if ! read -r _ans; then printf '\n'; log_line INFO "sem resposta (EOF): $1"; return 1; fi
    log_line INFO "pergunta: $1 -> resposta: $_ans"
    case $_ans in s|S|sim|Sim|SIM|y|Y|yes|Yes|YES) return 0;; *) return 1;; esac
}

# ---- execucao -----------------------------------------------------------------
# Executa um comando mostrando a saida no terminal e gravando no log; devolve o codigo real.
run_logged() {
    log_line CMD "$*"
    _rf=$(mktemp "${TMPDIR:-/tmp}/roblox-linux.XXXXXX" 2>/dev/null) || {
        "$@"; _rc=$?; log_line RC "$_rc"; return "$_rc"
    }
    { "$@" 2>&1; printf '%s' "$?" > "$_rf"; } | tee -a "$RL_LOG_FILE"
    _rc=$(cat "$_rf" 2>/dev/null); rm -f "$_rf"
    [ -n "$_rc" ] || _rc=1
    log_line RC "$_rc"
    return "$_rc"
}

is_root() { [ "${RL_UID_OVERRIDE:-$(id -u)}" = 0 ]; }

root_prefix() { if is_root; then printf ''; else printf 'sudo '; fi; }

as_root() {
    if is_root; then
        run_logged "$@"
    elif command -v sudo >/dev/null 2>&1; then
        run_logged sudo "$@"
    elif command -v doas >/dev/null 2>&1; then
        run_logged doas "$@"
    else
        err "Este passo precisa de privilégios de administrador e 'sudo' não foi encontrado."
        err "Execute como administrador (root): $*"
        return 1
    fi
}

# Compara versoes numericas pontuadas: ver_gt A B -> 0 se A > B
ver_gt() {
    awk -v a="$1" -v b="$2" 'BEGIN{n=split(a,x,".");m=split(b,y,".");k=(n>m?n:m);
        for(i=1;i<=k;i++){xi=x[i]+0;yi=y[i]+0;if(xi>yi)exit 0;if(xi<yi)exit 1}exit 1}'
}
