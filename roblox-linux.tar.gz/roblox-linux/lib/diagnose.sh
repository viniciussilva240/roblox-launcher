# lib/diagnose.sh - diagnostico

diag_problem() { DIAG_PROBLEMS="${DIAG_PROBLEMS}${DIAG_PROBLEMS:+
}$1"; }
diag_warning() { DIAG_WARNINGS="${DIAG_WARNINGS}${DIAG_WARNINGS:+
}$1"; }

diag_collect() {
    DIAG_PROBLEMS=""; DIAG_WARNINGS=""

    # Flatpak / Flathub / Sober
    if fp_present; then
        ST_FLATPAK="OK ($(fp_version))"
        _sc=$(sober_scope)
        if [ -n "$_sc" ]; then
            ST_SOBER="INSTALADO ($_sc${SOBER_VER:+, versão $SOBER_VER})"
        else
            ST_SOBER="NÃO INSTALADO"
            diag_problem "Roblox Linux (Sober) ainda não está instalado. Solução: ./launcher --install"
        fi
        if fp_remote_in "$INSTALL_SCOPE"; then ST_FLATHUB="OK ($INSTALL_SCOPE)"
        elif fp_remote_in user || fp_remote_in system; then ST_FLATHUB="OK (em outro escopo)"
        else
            ST_FLATHUB="AUSENTE"
            diag_problem "O repositório Flathub não está configurado. Ele é a fonte oficial do Sober. Solução: ./launcher --repair"
        fi
    else
        ST_FLATPAK="NÃO INSTALADO"; ST_FLATHUB="indisponível (sem Flatpak)"; ST_SOBER="NÃO INSTALADO"
        diag_problem "Flatpak não está instalado. É necessário porque o Sober (Roblox no Linux) é distribuído somente como Flatpak. Solução: ./launcher --install (distribuição detectada: $DISTRO_PRETTY)"
    fi

    # Sessao grafica
    if [ "$HAS_DISPLAY" != 1 ]; then
        diag_problem "Nenhuma sessão gráfica detectada (DISPLAY/WAYLAND_DISPLAY vazios). O Roblox precisa de um ambiente gráfico; não use SSH/console puro."
    fi

    # GPU / Vulkan
    if [ "$GPU_COUNT" -eq 0 ]; then
        diag_warning "Nenhuma GPU detectada (máquina virtual ou /sys indisponível). O Roblox precisa de aceleração gráfica para rodar bem."
    fi
    case $VULKAN_STATE in
        ok) ST_VULKAN="OK${VULKAN_DETAIL:+ ($VULKAN_DETAIL)}";;
        icd) ST_VULKAN="OK (driver Vulkan encontrado; instale vulkan-tools para verificação completa)";;
        software) ST_VULKAN="SOMENTE SOFTWARE"
            diag_warning "Vulkan encontrado apenas com renderização por software (llvmpipe). O desempenho será muito ruim. $(vulkan_fix_hint)";;
        fail) ST_VULKAN="COM PROBLEMA"
            diag_problem "O Vulkan está instalado, mas 'vulkaninfo' falhou ao listar uma GPU. $(vulkan_fix_hint)";;
        *) ST_VULKAN="NÃO ENCONTRADO"
            if [ -n "$GPU_NVIDIA_DRIVER" ]; then
                diag_warning "Driver NVIDIA detectado, mas o driver Vulkan não está disponível. $(vulkan_fix_hint)"
            else
                diag_warning "Vulkan não encontrado. $(vulkan_fix_hint)"
            fi;;
    esac
    if [ "$GPU_NVIDIA_DRIVER" = nouveau ]; then
        diag_warning "A GPU NVIDIA está usando o driver nouveau. Para melhor desempenho, instale o driver proprietário da NVIDIA (o launcher não altera drivers)."
    fi

    # Recursos
    if [ "$DISK_FREE_KB" -lt 3145728 ]; then
        diag_warning "Pouco espaço livre em $DISK_DIR ($DISK_FREE_HUMAN). Libere pelo menos 3 GB para o Sober e o Roblox."
    fi
    if [ "$MEM_KB" -gt 0 ] && [ "$MEM_KB" -lt 4194304 ]; then
        diag_warning "Pouca memória RAM ($MEM_HUMAN). Recomendado: 4 GB ou mais."
    fi
    if is_root; then
        diag_warning "Você está usando o usuário root. Recomenda-se usar um usuário comum para jogar."
    fi
}

cmd_diagnose() {
    detect_all
    SOBER_VER=""
    if fp_present && sober_installed; then SOBER_VER=$(sober_version); fi
    diag_collect

    banner "ROBLOX LINUX - DIAGNÓSTICO"
    printf '\n'
    printf '%-16s %s\n' "Sistema:" "$DISTRO_PRETTY"
    printf '%-16s %s (família: %s)\n' "Distro:" "$DISTRO_ID" "$DISTRO_FAMILY"
    printf '%-16s %s\n' "Kernel:" "$RL_KERNEL"
    printf '%-16s %s\n' "Arquitetura:" "$RL_ARCH"
    printf '%-16s %s (%s threads)\n' "CPU:" "$CPU_MODEL" "$CPU_THREADS"
    printf '%-16s %s\n' "RAM:" "$MEM_HUMAN"
    printf '%-16s %s (em %s)\n' "Disco livre:" "$DISK_FREE_HUMAN" "$DISK_DIR"
    printf '%-16s %s, desktop: %s\n' "Display:" "$SESSION_LABEL" "$SESSION_DESKTOP"
    if [ "$GPU_COUNT" -eq 0 ]; then
        printf '%-16s %s\n' "GPU:" "não detectada"
    else
        _i=0
        _oldifs=$IFS
        IFS='
'
        for _rec in $GPU_LIST; do
            IFS=$_oldifs
            _i=$((_i + 1))
            _gv=${_rec%%|*}; _rest=${_rec#*|}; _gd=${_rest%%|*}; _gn=${_rest#*|}
            if [ "$GPU_COUNT" -gt 1 ]; then _sfx=" $_i"; else _sfx=""; fi
            printf '%-16s %s\n' "GPU${_sfx}:" "$_gn"
            printf '%-16s %s\n' "Fabricante${_sfx}:" "$_gv"
            printf '%-16s %s\n' "Driver${_sfx}:" "$(gpu_driver_label "$_gd")"
            IFS='
'
        done
        IFS=$_oldifs
    fi
    printf '%-16s %s\n' "Vulkan:" "$ST_VULKAN"
    printf '%-16s %s\n' "Pacotes:" "${PM:-gerenciador não identificado}"
    printf '%-16s %s\n' "Flatpak:" "$ST_FLATPAK"
    printf '%-16s %s\n' "Flathub:" "$ST_FLATHUB"
    printf '%-16s %s\n' "Sober:" "$ST_SOBER"
    printf '%-16s %s\n' "Launcher:" "$RL_VERSION"
    printf '%-16s %s\n' "Log:" "$RL_LOG_FILE"

    if [ "$RL_DEBUG" = 1 ]; then diag_debug_details; fi

    if [ -n "$DIAG_WARNINGS" ]; then
        printf '\nAvisos:\n'
        printf '%s\n' "$DIAG_WARNINGS" | while IFS= read -r _l; do printf '  - %s\n' "$_l"; done
    fi
    if [ -n "$DIAG_PROBLEMS" ]; then
        printf '\nProblemas:\n'
        printf '%s\n' "$DIAG_PROBLEMS" | while IFS= read -r _l; do printf '  - %s\n' "$_l"; done
    fi
    printf '\n'
    if [ -z "$DIAG_PROBLEMS" ]; then
        printf 'STATUS: PRONTO\n'
        log_line INFO "diagnóstico: PRONTO"
        _drc=0
    else
        printf 'STATUS: PROBLEMA DETECTADO\n'
        log_line INFO "diagnóstico: PROBLEMA DETECTADO"
        _drc=1
    fi
    printf '\n========================================\n'
    return "$_drc"
}

diag_debug_details() {
    printf '\n--- Detalhes (--debug) ---\n'
    printf 'Pasta do launcher : %s\n' "$RL_ROOT"
    printf 'Escopo configurado: %s\n' "$INSTALL_SCOPE"
    printf 'App ID            : %s\n' "$SOBER_APP_ID"
    printf 'Remoto Flathub    : %s -> %s\n' "$FLATHUB_REMOTE_NAME" "$FLATHUB_REPO_URL"
    printf 'XDG_SESSION_TYPE  : %s\n' "${XDG_SESSION_TYPE:-}"
    printf 'DISPLAY           : %s\n' "${DISPLAY:-}"
    printf 'WAYLAND_DISPLAY   : %s\n' "${WAYLAND_DISPLAY:-}"
    if command -v xdg-mime >/dev/null 2>&1; then
        printf 'Handler roblox-player: %s\n' "$(xdg-mime query default x-scheme-handler/roblox-player 2>/dev/null)"
    fi
    if [ -n "${VULKAN_RAW:-}" ]; then
        printf '\n--- vulkaninfo --summary ---\n%s\n' "$VULKAN_RAW"
    fi
    if fp_present; then
        printf '\n--- flatpak remotes ---\n'; flatpak remotes 2>&1
        printf '\n--- flatpak list --app ---\n'; flatpak list --app 2>&1
    fi
    printf '\n'
}
