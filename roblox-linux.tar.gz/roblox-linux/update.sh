#!/bin/sh
# Atalho para: ./launcher --update
_d=$(cd "$(dirname "$0")" 2>/dev/null && pwd -P) || exit 1
exec "$_d/launcher" --update "$@"
